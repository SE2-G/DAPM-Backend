import sys
import pandas as pd
from pm4py.algo.discovery.alpha import algorithm as alpha_miner
from pm4py.objects.log.util import dataframe_utils
from pm4py.objects.conversion.log import converter as log_converter
from pm4py.objects.log.exporter.xes import exporter as xes_exporter

def main(input_file, output_file):
    # Read the CSV log file
    df = pd.read_csv(input_file)
    
    # Convert the dataframe to a pm4py event log
    df = dataframe_utils.convert_timestamp_columns_in_df(df)
    log = log_converter.apply(df)

    print(f"INPUT FILE: {input_file}, OUTPUT FILE: {output_file}")

    # If you want to export to XES format instead, comment the line above and uncomment this:
    xes_exporter.apply(log, output_file)

if __name__ == "__main__":
    # Get command-line arguments (input and output file paths)
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    # Run the main function
    main(input_file, output_file)
